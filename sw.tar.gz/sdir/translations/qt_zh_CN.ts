<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<dependencies>
<dependency catalog="qtbase_zh_CN"/>
<dependency catalog="qtmultimedia_zh_CN"/>
</dependencies>
</TS>
