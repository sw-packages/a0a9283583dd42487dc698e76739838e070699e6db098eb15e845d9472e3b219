<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
    <dependencies>
        <dependency catalog="qtbase_hu"/>
        <dependency catalog="qtmultimedia_hu"/>
    </dependencies>
</TS>
