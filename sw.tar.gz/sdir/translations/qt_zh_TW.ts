<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
  <dependencies>
    <dependency catalog="qtbase_zh_TW"/>
    <dependency catalog="qtmultimedia_zh_TW"/>
  </dependencies>
</TS>
